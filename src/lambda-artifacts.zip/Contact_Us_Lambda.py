import json
import boto3
from botocore.vendored import requests
import os
import smtplib
import datetime, dateutil.tz
import base64,hashlib
import sys

ssm = boto3.client('ssm', 'ap-south-1')

#******************************  ACCESS KEY  ***********************************

def get_parameters_ak():
    resp_Ak = ssm.get_parameters(
        Names=['KEY_AWS_AK'],WithDecryption=True
    )
    for parameter in resp_Ak['Parameters']:
        return parameter['Value']    

#******************************  SECRET KEY ************************************

def get_parameters_sk():
    resp_Sk = ssm.get_parameters(
        Names=['KEY_AWS_SK'],WithDecryption=True
    )
    for parameter in resp_Sk['Parameters']:
        return parameter['Value']    
#******************************  Gmail App  ************************************        
def gmail_password():
    app_password = ssm.get_parameters(
        Names=['App_Password'],WithDecryption=True
)
    for parameter in app_password['Parameters']:
        return parameter['Value']    

def lambda_handler(event, context):
    
    value_ak = get_parameters_ak()
    value_sk = get_parameters_sk()

#*****************************  S3, FILE UPLODE  *******************************
    
    aDict = json.dumps(event)
    jsonString = aDict
    
    IST = dateutil.tz.gettz('Asia/Kolkata')
    time = datetime.datetime.now(tz=IST)
    
    clock = time.strftime("%Y-%m-%d %H:%M:%S")
    print("Curent Time: ",clock)
    ct = clock
    print('current datetime: ',ct)
    fileNameJson = "/tmp/"+ct+".json"
    print("filename: ",fileNameJson)
    
    jsonFile = open(fileNameJson, "w+")
    jsonFile.write(jsonString)
    path = "/tmp"
    dir_list = os.listdir(path)
    print(dir_list)
    jsonFile.close()
    
    s3 = boto3.client(
            's3',
        aws_access_key_id = value_ak,
        aws_secret_access_key = value_sk
    )
    
    filename = fileNameJson
    bucket_name = os.environ.get('bucketname')
    s3.upload_file(filename, bucket_name, filename)
    
    
#*****************************  SENDER SIDE  ***********************************
    
    #print("Data from postman: ",event)
    data = json.loads(event["body"])

    receiver = data.get('email')
    sender = os.environ.get('Sender')
    name = data.get('name')
    messages = data.get('message')
    phone = data.get('phone')
   
    gmail_user = os.environ.get('gmailuser')
    gmail_app_password = gmail_password()
    sent_from = gmail_user
    sent_to = sender
    
    email_text = """From:"""+gmail_user+"""
To : """+sent_to+"""
Subject: Contact Us Email Notification.
Name """+name+"""
Email """+receiver+"""
Phone """+phone+"""
message"""+messages+"""
"""

    try:
        server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
        server.ehlo()
        server.login(gmail_user, gmail_app_password)
        server.sendmail(sent_from, sent_to, email_text)
        server.close()
    
        print('  Email Sent Successfully for Email Notification - Contact Us.')
    except Exception as exception:
        print("Error: %s!\n\n" % exception)
        
        
#*****************************  RECIVER SIDE  **********************************

    msg="Thanks for selecting us, we will soon get in touch with you..."
    message1 = """From:"""+gmail_user+ """
To : """+receiver+"""
Subject: Contact-Us Acknowledgment.
Hello,"""+name+"""
message"""+msg+"""
"""
    email_text1 = message1
    sent_to1 = receiver
    
    try:
        server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
        server.ehlo()
        server.login(gmail_user, gmail_app_password)
        server.sendmail(sent_from, sent_to1, email_text1)
        server.close()
    
        print('  Email Sent successfully for Contact-Us Acknowledgment.')
    except Exception as exception:
        print("Error: %s!\n\n" % exception)
 
 
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
